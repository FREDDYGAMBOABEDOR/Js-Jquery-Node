let factorial = 1

for (let i = 10; i > 0; i--) {
    factorial = factorial*i
    //10*1 = 10 * 9 * 8
}
console.log(factorial)


