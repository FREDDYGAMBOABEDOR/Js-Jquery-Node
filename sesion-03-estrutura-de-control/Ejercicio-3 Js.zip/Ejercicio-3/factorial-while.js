
let factorial = 1
let contador = 10
while (contador > 1) {
    factorial *= contador
    contador--// cierre de control
}
console.log(factorial) 